var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var app = express();
app.use(session({
    secret: '2C44-4D44-WppQ38S',
    resave: true,
    saveUninitialized: true
}));

app.set('views', __dirname + '/views');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

var sess;


var auth = function(req, res) {
  if (!(req.session && req.session.first == "Marko" && req.session.second == "Pavic"))
    return res.sendStatus(401);
};

// Login endpoint
app.get('/login', function (req, res) {
  if (!req.query.first || !req.query.second) {
    res.send('login failed');    
  } else if(req.query.first === "Marko" || req.query.password === "Pavic") {
    req.session.first = "Marko";
    req.session.second = "Pavic";
    res.send("login success!");
  }
});

var server = app.listen(8081, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Example app listening at http://%s:%s", host, port)

})