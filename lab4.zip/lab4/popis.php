<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main2.css">

		
		<meta charset="UTF-8">
		
		<title>dwa</title>
	</head>
	<body>
	
	<div class="container">

		<table style="width:100%">
		  <tr>
			<th>Naziv</th>
			<th>Opis</th>
			<th>Cijena</th>		
		  </tr>
		</table>
			<?php  
				require_once 'idiorm.php';
				ORM::configure('mysql:host=localhost;dbname=labos');
				ORM::configure('username', 'root');
				ORM::configure('password', 'root');
				ORM::configure('return_result_sets', true);
				
				$Pro = ORM::for_table('Proizvodi')->find_many();
				
				
				foreach ($Pro as $tweet) {
						echo $tweet->text;
					}
					
					?>
			<form>		
			<input type="text" name="sort" id="sort" placeholder="Filter" onkeyup="Filtiranje()"><br><br>
			</form>

		</table>
			<br><br><br><br><br><br><br><br><br><br>
			</div>
			<hr>
			<div class="container">
			<footer>
				<p>Copyright Fantastic beasts, 2016</p>
			</footer>
		</div>
		
			<script>
		function Filtiranje() {
				
				var x = document.getElementsByTagName("tr");  //x[0].innerHTML; x.lenght
				var upis=document.getElementById("sort").value;
				var i;

				for(i=0; i < x.length; i++)
				{
					if((x[i].innerHTML).search(upis)==-1)
						x[i].style="display:none";
					else 
						x[i].style="display:table";
				}
		}
			</script>	
	</body>
</html>