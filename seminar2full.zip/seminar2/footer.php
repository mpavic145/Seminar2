<!--  Footer svake stranice  -->

<footer>
	<br></br><br></br>
	<p>Copyright Marko Pavić, Zrino Pernar
	<a href="#logo"><img src="img/return.png" alt="return_to_the_top" width="50"></a>

	    <img style="border:0;width:88px;height:31px"
		src="http://jigsaw.w3.org/css-validator/images/vcss-blue"
		alt="Valid CSS!" />
	</p>
	</footer>
	</div>
</footer>