<!-- Slike ruta (transportne linije) -->

<div>
		<div class="ruta"><p>Rijeka</p>
		<a href="img/ri-hr.png"><img class="rute" src="img/ri-hr.png" height="200" width="465" alt="Rijeka"></a><br><br><hr> </div>
		<div class="ruta"><p>Zadar</p>
		<a href="img/zd-hr.png"><img class="rute" src="img/zd-hr.png" height="200" width="465" alt="Zadar"></a><br><br><hr></div>
		<div class="ruta"><p>Šibenik</p>
		<a href="img/sib-hr.png"><img class="rute" src="img/sib-hr.png" height="200" width="465" alt="Šibenik"></a><br><br><hr></div>
		<div class="ruta"><p>Split</p>
		<a href="img/spl-hr.png"><img class="rute" src="img/spl-hr.png" height="200" width="465" alt="Split"></a><br><br><hr></div>
		<div class="ruta"><p>Dubrovnik</p>
		<a href="img/du-hr.png"><img class="rute" src="img/du-hr.png" height="200" width="465" alt="Dubrovnik"></a><br><br><hr></div>
</div>

