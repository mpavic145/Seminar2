<?php

	$upit = $_GET["upit"];
	$polje = [];
	require_once 'idiorm.php';
				ORM::configure('mysql:host=localhost;dbname=labos;array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")');
				ORM::configure('username', 'root');
				ORM::configure('password', 'root');
				ORM::configure('return_result_sets', true);
				
				$query = ORM::for_table('Proizvodi')->where_like('Naziv', '%'.$upit.'%')
								->find_many();
								
		foreach($query as $result):

				$polje[] = ["ID"=> $result->ID, "Naziv" => $result->Naziv, "Cijena"=> $result->Cijena_Proizvoda];
			endforeach;
			
			
 	echo  json_encode($polje);		  



?>	