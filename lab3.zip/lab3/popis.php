<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main2.css">

		
		<meta charset="UTF-8">
		
		<title>dwa</title>
	</head>
	<body>
	
	<div class="container">

		<table style="width:100%">
		  <tr>
			<th>Naziv</th>
			<th>Opis</th>
			<th>Cijena</th>		
		  </tr>

			<?php                                                   
						$servername = "localhost";
						$username = "root";
						$password = "root";
						$dbname = "labos";

						echo '<h3>Popis proizvoda</h3>';
						$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
												// set the PDO error mode to exception
												$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						
												$sth = $conn->prepare("SELECT Naziv, Opis_Proizvoda, Cijena_Proizvoda FROM Proizvodi ORDER BY Naziv ASC");
												$sth->execute();
												$result = $sth->fetchAll();
												
													foreach( $result as $row )  
												{  
													echo'<tr>'.'<td>'.$row['Naziv'].'</td>'.'<td>'.$row['Opis_Proizvoda'].'</td>'.'<td>'.$row['Cijena_Proizvoda'].'</td>'.'</tr>';
												}
													
			
						$conn = null;
					
					
					?>
			<form>		
			<input type="text" name="sort" id="sort" placeholder="Filter" onkeypress="Filtiranje()"><br><br>
			</form>

		</table>
			<br><br><br><br><br><br><br><br><br><br>
			</div>
			<hr>
			<p id="demo"> </p>
			<div class="container">
			<footer>
				<p>Copyright Fantastic beasts, 2016</p>
			</footer>
		</div>
		
			<script>
		function Filtiranje() {
				var x = document.getElementsByTagName("td");  //x[0].innerHTML; x.lenght
				var upis=document.getElementById("sort").value;
				var i;
				
				for(i=0; i < x.lenght; i++)
				{
				document.getElementById("demo").innerHTML=x[0].innerHTML;

					
				}
		}
			</script>	
	</body>
</html>