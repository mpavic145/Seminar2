<?php
session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main2.css">
		<meta charset="UTF-8">
		
		<title>dwa</title>
	</head>
	<body>

	<?php
			$cookie_name = "kosarica";


			if(!isset($_COOKIE[$cookie_name])) {
				echo "Cookie named '" . $cookie_name . "' is not set!";
			} else {
				echo "Cookie '" . $cookie_name . "' is set!<br>";
				echo "Value is: " . $_COOKIE[$cookie_name];
			}
			?>
			
			
			
	<?php
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "labos";
    $value = 2;
	
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
												// set the PDO error mode to exception
												$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						
												$sth = $conn->prepare("SELECT Naziv, Opis_Proizvoda, Cijena_Proizvoda FROM Proizvodi WHERE ID = :id ORDER BY Naziv ASC ");
												$stmt->bindParam(':id', $value);
												$sth->execute();
												$result = $sth->fetchAll();
												
													foreach( $result as $row )  
												{  
													echo'<tr>'.'<td>'.$row['Naziv'].'</td>'.'<td>'.$row['Opis_Proizvoda'].'</td>'.'<td>'.$row['Cijena_Proizvoda'].'</td>'.'</tr>';
												}
													
			
						$conn = null;
	
	
	
	?>
			
			
	<hr>
			<div class="container">
			<footer>
				<p>Copyright Fantastic beasts, 2016</p>
				<p id="demo"> </p>
			</footer>
		</div>
	</body>
</html>