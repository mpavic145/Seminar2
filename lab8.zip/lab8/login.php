<?php
	error_reporting(E_ALL);					
	session_start();
						
	$_SESSION["nick"] = "mpavic";
	$_SESSION["password"] = "labos";
	
	
	$nick=$_POST["username"];
	$sifra=$_POST["password"];
	
	if($nick!=$_SESSION["nick"] || $sifra!=$_SESSION["password"]){
		echo "Netočni ulazni podaci";
	}
	else{
	echo '				

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main1.css">
		
		<meta charset="UTF-8">
		
		<title>dwa</title>
	
		
	</head>
	<body>

			<div id="phplogo">
				<img src="fantBeastsLogo.png" width="200" alt="logo">
			</div>
			
			<div id="okomitanavigacija">
				<p><strong>Izbornik</strong></p>
				<ul class="nav nav-pills nav-stacked">
				  <li role="presentation" class="active"><a href="#osobno"><strong>Osobni podaci</strong></a></li>
				  <li role="presentation" class="active"><a href="#skolovanje"><strong>Podaci o školovanju</strong></a></li>
				  <li role="presentation" class="active"><a href="#posao"><strong>Podaci o radnom iskustvu</strong></a></li>
				  <li role="presentation" class="active"><a href="#vjestine"><strong>Znanja i vještine</strong></a></li>
				</ul>
			</div>
			
			
			<div id="logout">
			
				<a href="logout.php"><button type="button" class="btn btn-primary">Odjava</button></a>
			
			</div>
			
			<div id="nick">
					<div id="pomicanje" style="margin-left: 550px;">

						' . $_POST["username"] . '
			
				</div>
			</div>
			
	
	
		<div id="pomak">
			<div class="container">
			<br><br><br><br><br><br>
				
				<div id="sadrzaj">
					<h1>Životopis</h1>
					<br>
					
					<div id="osobno">
						<h3>Osobni podaci</h3>
						<pre>Ime: Marko</pre>
						<pre>Prezime: Pavić</pre>
						<pre>Datum rođenja: 14.05.1994.</pre>
					</div>
					
					<div id="skolovanje">
						<h3>Podaci o školovanju</h3>
						<pre>Osnovna škola: Osnovna škola Ivana Meštrovića</pre>
						<pre>Srednja škola: Elektrotehnička škola</pre>
						<pre>Fakultet: Tehničko veleučilište</pre>	
					</div>
					
					<div id="posao">
						<h3>Podaci o radnom iskustvu</h3>
						<pre>Radno iskustvo: Nikakvo</pre>
						<pre>Prijašnja zaposlenja: -</pre>
					</div>
					
					<div id="vjestine">
						<h3>Znanja i vještine</h3>
						<pre>Aktivno znanje engleskog jezika</pre>
						<pre>Osnovna razina znanja programiranja u c,c++,javi,c# jeziku</pre>
						<pre>Osnovna razina znanja rada s bazama podataka</pre>
						<pre>Osnovna razina znanja s HTML-om,CSS-om,JavaScript-om i PHP-om</pre>
						<pre>Timski rad</pre>
						<pre>Vozačka dozvola B kategorija</pre>
					</div>
				
				
				
						
		<button id="hide">Hide</button>
		<button id="show">Show</button>
				
				</div>
			</div>
		</div>
					
		<br><br><br><br><br><br><br><br><br><br><br><br>
		<hr>

		
		

		<footer>
			<p>Copyright Fantastic beasts, 2016</p>
		</footer>

		
		
		
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
		<script>
		$(document).ready(function(){
			$("#hide").click(function(){
				$("pre").hide();
				$("h3").hide();
				$("h1").hide();
			});
			$("#show").click(function(){
				$("pre").show();
				$("h3").show();
				$("h1").show();
			});
		});
		</script>
	
	
	
	
	
	</body>
</html>
	';}
	?>