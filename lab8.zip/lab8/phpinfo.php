<?php

	phpinfo()
	?>