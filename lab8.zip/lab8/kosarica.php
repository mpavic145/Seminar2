<?php
session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main2.css">
		<meta charset="UTF-8">
		
		<title>dwa</title>
	</head>
	<body>
	
		<div class="container">
		
		
		<?php
		$cookie_name="kosarica";
				
	/*		if(!isset($_COOKIE[$cookie_name])) {
			echo "Cookie named '" . $cookie_name . "' is not set!";
		} else {
			echo "Cookie '" . $cookie_name . "' is set!<br>";
			echo "Value is: " . $_COOKIE[$cookie_name];
		}
		*/
		
			
				$string = $_COOKIE[$cookie_name];
				$value = array();
				$i=0;
		/* Use tab and newline as tokenizing characters as well  */
		$tok = strtok($string, "->");

		while ($tok !== false) {
			$value[]=$tok;
			
			$tok = strtok("->");
				}
		
		
				
		require_once 'idiorm.php';
				ORM::configure('mysql:host=localhost;dbname=labos;array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")');
				ORM::configure('username', 'root');
				ORM::configure('password', 'root');
				ORM::configure('return_result_sets', true);
				
				$query = ORM::for_table('Proizvodi')->where_id_in($value)
								->find_many();
								
								
								
				foreach($query as $result):
				 echo "
						<div class='Naziv'><b>$result->Naziv</b> <br>" . "$result->Opis_Proizvoda" . "</div>
						<div class='Cijena'>$result->Cijena_Proizvoda" . "kn<br><br>" . "</div>
					";
				   endforeach;

		?>
		
		</div>
	</body>
</html>