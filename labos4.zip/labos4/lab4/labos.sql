/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.7.8-rc : Database - labos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`labos` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_croatian_ci */;

USE `labos`;

/*Table structure for table `Proizvodi` */

DROP TABLE IF EXISTS `Proizvodi`;

CREATE TABLE `Proizvodi` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Naziv` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  `Tip_Zivotinje` int(10) unsigned NOT NULL,
  `Tip_Proizvoda` int(10) unsigned NOT NULL,
  `Opis_Proizvoda` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `Cijena_Proizvoda` float unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Tip_Zivotinje` (`Tip_Zivotinje`),
  KEY `Tip_Proizvoda` (`Tip_Proizvoda`),
  CONSTRAINT `Proizvodi_ibfk_5` FOREIGN KEY (`Tip_Zivotinje`) REFERENCES `Tip_Zivotinja` (`ID`),
  CONSTRAINT `Proizvodi_ibfk_6` FOREIGN KEY (`Tip_Proizvoda`) REFERENCES `Tip_Proizvoda` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

/*Data for the table `Proizvodi` */

insert  into `Proizvodi`(`ID`,`Naziv`,`Tip_Zivotinje`,`Tip_Proizvoda`,`Opis_Proizvoda`,`Cijena_Proizvoda`) values (1,'WHISKAS',2,1,'Suha hrana za mačke Piletina 1+, 1,4kg',30),(2,'ALLEVA CARE Sensitive Digestion Adult',1,1,'Potpuna hrana za odrasle pse osjetljive probave',50),(3,'VERSELE-LAGA Prestige Menu Nature',4,1,'Mješavina za divlje ptice 1kg',5),(4,'JBL NovoGranoColor Mini R',5,1,'Granule za intenzivniju boju ribica 100ml',20),(5,'JBL Calcil',6,1,'Mineralna hrana u štapićima i tabletama za kornjače 250ml',20),(6,'CUNIPIC Gerbil',3,1,'Potpuna, prirodna hrana za kućne ljubimce, za GERBILE, 700g,',25),(7,'FERPLAST Volijera za ptice Giulietta 4',4,3,'Giulietta je volijera pogodna za kanarince i male egzotične ptice drvene konstrukcije',25),(8,'FERPLAST',3,5,'Igračka za glodanje',5),(9,'ZOO MED Repti Sand Scooper',6,4,'Lopatica za prosijavanje terarijskog pijeska',15),(10,'ALPHA SPIRIT',1,2,'Poslastica za psa Kost Large, 330g',20),(11,'JBL Pond Termometar',5,3,'Plutajući termometar za ribnjake',80);

/*Table structure for table `Tip_Proizvoda` */

DROP TABLE IF EXISTS `Tip_Proizvoda`;

CREATE TABLE `Tip_Proizvoda` (
  `ID` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `Proizvodi` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

/*Data for the table `Tip_Proizvoda` */

insert  into `Tip_Proizvoda`(`ID`,`Proizvodi`) values (1,'hrana'),(2,'poslastice'),(3,'oprema'),(4,'higijena'),(5,'ostalo');

/*Table structure for table `Tip_Zivotinja` */

DROP TABLE IF EXISTS `Tip_Zivotinja`;

CREATE TABLE `Tip_Zivotinja` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Vrste` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

/*Data for the table `Tip_Zivotinja` */

insert  into `Tip_Zivotinja`(`ID`,`Vrste`) values (1,'pas'),(2,'mačka'),(3,'glodavci'),(4,'ptice'),(5,'ribice'),(6,'gmazovi'),(7,'ostalo');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
