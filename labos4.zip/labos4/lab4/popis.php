<?php
session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main2.css">
		<meta charset="UTF-8">
		
		<title>dwa</title>
	</head>
	<body>
	
	<div class="container">

		<table style="width:100%">

			<?php 
				require_once 'idiorm.php';
				ORM::configure('mysql:host=localhost;dbname=labos;array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")');
				ORM::configure('username', 'root');
				ORM::configure('password', 'root');
				ORM::configure('return_result_sets', true);
				
				$query = ORM::for_table('Proizvodi')
								->find_many();
								
								
								
				foreach($query as $result):
				 echo "
						<tr>
						<td><div class='Naziv'><b>$result->Naziv</b> <br><br> " . "$result->Opis_Proizvoda" . "</div></td>
						<td><div class='Cijena'>$result->Cijena_Proizvoda" . "kn" . "</div></td>
						<td><button type=\"button\" onclick=\"dodajCookie($result->ID)\">Dodaj!</button></td>
						</tr>
						
						
					";
				   endforeach;
					

					?>
			<form>		
			<input type="text" name="sort" id="sort" placeholder="Filter" onkeyup="Filtiranje()"><br><br>
			</form>

		</table>
			<br><br><br><br><br><br><br><br><br><br>
			</div>
			<hr>
			<div class="container">
			<footer>
				<p>Copyright Fantastic beasts, 2016</p>
				<p id="demo"> </p>
			</footer>
		</div>
		
			<script>
		function Filtiranje() {
				
				var x = document.getElementsByTagName("tr");  //x[0].innerHTML; x.lenght
				var upis=document.getElementById("sort").value;
				var i;

				for(i=0; i < x.length; i++)
				{
					if((x[i].innerHTML).search(upis)==-1)
						x[i].style="display:none";
					else 
						x[i].style="display:table";
				}
		}
		
		function dodajCookie(x)
		{
				document.getElementById("demo").innerHTML = x;
				
				var cname="kosarica";
				var cvalue=x;
				
				var d = new Date();
				d.setTime(d.getTime() + (1*24*60*60*1000));
				var expires = "expires="+d.toUTCString();
				
				var kupovina = getCookie('kosarica');
					if (kupovina == "") {
						
						setCookie("kosarica",x);

					}
				 else {
				 setCookie('kosarica',kupovina+ "->"+x);
				 }
		}
		
		
		
		function getCookie(cname) {
					var name = cname + "=";
					var ca = document.cookie.split(';');
					for(var i=0; i<ca.length; i++) {
						var c = ca[i];
						while (c.charAt(0)==' ') c = c.substring(1);
						if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
					}
					return "";
				} 
				function setCookie(cname, cvalue) {
						var d = new Date();
						d.setTime(d.getTime() + (1*24*60*60*1000));
						var expires = "expires="+d.toUTCString();
						document.cookie = cname + "=" + cvalue + "; " + expires;
					}	

			</script>	
	</body>
</html>