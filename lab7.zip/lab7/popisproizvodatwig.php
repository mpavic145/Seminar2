<?php
include("../vendor/autoload.php");

/*if(!isset($_COOKIE["kosarica"])) {
  echo "Cookie named kosarica is not set!";
} else {
  echo "Cookie kosarica is set!<br>";
  echo "Value is: " . $_COOKIE["kosarica"];
}*/

$loader = new Twig_Loader_Filesystem('./');
$twig = new Twig_Environment($loader, array(
    'cache' => false,
));

$dbc= mysqli_connect('localhost', 'root','root', 'labos') or die('Error connecting to MySQL.');
mysqli_set_charset($dbc, "utf8");

$query= "SELECT ID, Naziv, Opis_Proizvoda, Cijena_Proizvoda FROM Proizvodi";

$result= mysqli_query($dbc, $query) or die("Error quering database");

echo $twig->render('popisproizvodatwig.html', array('result' => $result));

?>

