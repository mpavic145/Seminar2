<?php
include("/vendor/autoload.php");
if(!isset($_COOKIE["shop"])) {
        // echo "Cookie named shop is not set!";
} else {
            //echo "Cookie shop is set!<br>";
         //echo "Value is: " . $_COOKIE["shop"] . '<br>';
}

$dbc= mysqli_connect('localhost', 'root','root', 'fantastic') or die('Error connecting to MySQL.');
mysqli_set_charset($dbc, "utf8");
$token = substr($_COOKIE["shop"],1);

        //$token =(int)strtok($string, "-");

if (strlen($token) >0){

  $query= "SELECT id, opis, naziv, cijena from proizvod where id in (" . $token.")";
            //echo "$token<br>";
            //$token = strtok("-");

  }

  $result= mysqli_query($dbc, $query) or die("Error quering database");

  $loader = new Twig_Loader_Filesystem('./');
  $twig = new Twig_Enviroment($loader, array('cache' => false));
  echo $twig->render('shoppingCart.html', array('query' => $query));


?>

<!-- 
<script type="text/javascript"> 

  function trazi(){
    var unos = document.getElementById("search").value;
    var find= document.getElementsByTagName("TR");

    for(var i=1; i< find.length; i++){
      var c= find[i].innerHTML.search(unos);
      if(c == -1){
        find[i].style.display="none";
      }
    }

  }


  function setCookie(cname, cvalue, exdays) {
    window.alert("NE RADI");
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
  }  

  function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0)==' ') c = c.substring(1);
      if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
  }  


</script> -->


