<?php
include("/vendor/autoload.php");

if(!isset($_COOKIE["shop"])) {
  echo "Cookie named shop is not set!";
} else {
  echo "Cookie shop is set!<br>";
  echo "Value is: " . $_COOKIE["shop"];
}

$loader = new Twig_Loader_Filesystem('./');
$twig = new Twig_Environment($loader, array(
    'cache' => false,
));

$dbc= mysqli_connect('localhost', 'root','root', 'fantastic') or die('Error connecting to MySQL.');
mysqli_set_charset($dbc, "utf8");

$query= "SELECT id, opis, naziv, cijena from proizvod";

$result= mysqli_query($dbc, $query) or die("Error quering database");

echo $twig->render('proizvodi1.html', array('result' => $result));

?>

