<?php
include("../vendor/autoload.php");

$loader = new Twig_Loader_Filesystem('./');
$twig = new Twig_Environment($loader, array(
    'cache' => false,
));

$dbc= mysqli_connect('localhost', 'root','root', 'labos') or die('Error connecting to MySQL.');
mysqli_set_charset($dbc, "utf8");


		$string = $_COOKIE["kosarica"];
		$value = array();
		/* Use tab and newline as tokenizing characters as well  */
		$tok = strtok($string, "->");

		while ($tok !== false) {
			$value[]=$tok;
			
			$tok = strtok("->");
				}
				
				
if (count($value)>0){


$matches = implode(', ', $value);
echo $matches;

  $query= "SELECT Naziv, Cijena_Proizvoda FROM Proizvodi WHERE ID IN ($matches)";
  }
  

  $result= mysqli_query($dbc, $query) or die("Error quering database");
  
  echo $twig->render('kosarica.html', array('query' => $result));


?>