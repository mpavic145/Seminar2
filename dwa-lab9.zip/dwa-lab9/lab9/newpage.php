<?php
session_start();
?>


<script>
  var query = window.location.search;
  // Skip the leading ?, which should always be there,
  // but be careful anyway
  if (query.substring(0, 1) == '?') {
    query = query.substring(1);
  }
  var data = query.split(',');
  for (i = 0; (i < data.length); i++) {
    data[i] = unescape(data[i]);
  }
  
  document.getElementById("opis").innerHTML =  data[0];
  
</script>


<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main2.css">
		<meta charset="UTF-8">
		
		<title>dwa</title>
	</head>
	<body>
		
		
		<br>
		<div id="opis">
	
	
		</div>
		<br><br><br><br>
		<input type="button" value="Prethodni">
		<input type="button" value="Sljedeći">
	
	
	</body>
	</html>