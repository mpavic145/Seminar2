﻿<?php
session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
		<link rel="stylesheet" type="text/css" href="main2.css">
		<meta charset="UTF-8">
		
		<title>dwa</title>
	</head>
	<body onload="myAjaxFunction()">
	
	<div class="container">



					
		
		<div id="pozivzabla"></div>
		<br><br><br>
		<div id="opis"></div>
		<br><br>
		<input type="text" id="inputPolje" onkeyup="myAjaxFunction()">


			<br><br><br><br><br><br><br><br><br><br>
			</div>
			<hr>
			<div class="container">
			<footer>
				<p>Copyright Fantastic beasts, 2016</p>
				<p id="demo"> </p>
			</footer>
		</div>
		
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

			<script>
			
			request = new XMLHttpRequest();
			
			function myAjaxFunction() { 
			
					//?upit="+document.getElementById("inputPolje").value
				request.open("GET", "bla.php?upit="+document.getElementById("inputPolje").value, true);
				request.onreadystatechange = updatePage;
				request.send(null);
			}
			
		
			function updatePage() { 
				if (request.readyState == 4 && request.status== 200) 
				{ 
				
				    objekti = JSON.parse( request.responseText );
					

	
					
					var tablica = '<table><tr><th></th><th>Naziv</th>';
					for (var i=0 ; i<objekti.length ; i++) {
						tablica += '<tr onclick="podaci(\''+objekti[i].ID+'\')"> <td>'+objekti[i].ID +'</td><td>' +objekti[i].Naziv +'</td></tr>';
					}
					
					tablica += '</table>';
					document.getElementById("pozivzabla").innerHTML =  tablica;
				} 
			}
			
			function podaci(x)
			{
				
				request.open("GET", "bla.php?upit="+x, true);
				request.onreadystatechange = updatePage1;
				request.send(null);
			}
			
			
			
			function updatePage1() { 
				if (request.readyState == 4 && request.status== 200) 
				{ 
				
				    objekti = JSON.parse( request.responseText );
					

	
					
					var tablica = '<table><tr><th></th><th>Naziv</th><th>Opis</th>';
					for (var i=0 ; i<objekti.length ; i++) {
						tablica += '<tr onclick="podaci(\''+objekti[i].ID+'\')"> <td>'+objekti[i].ID +'</td><td>' +objekti[i].Naziv +'</td><td>' +objekti[i].Opis +'</td></tr>';
					}
					
					tablica += '</table>';
					document.getElementById("opis").innerHTML=tablica;
				} 
			}
						

			</script>
			
	</body>
</html>