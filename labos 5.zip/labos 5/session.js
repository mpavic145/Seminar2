var express = require('express'),
    app = express(),
    session = require('express-session');
	bodyParser = require('body-parser');

	
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
	
	
	
app.use(session({
    secret: '2C44-4D44-WppQ38S',
    resave: true,
    saveUninitialized: true
}));

app.get('/post.html', function (req, res) {
   res.sendFile( __dirname + "/" + "post.html" );
})


app.post('/process_post',function (req, res) {
  if (!req.body.username || !req.body.password ) {
    res.send('login failed');    
  } else if(req.body.username === "Marko" || req.body.password === "proba145") {
    req.session.user = "Marko";
    req.session.admin = true;
    res.send("login success!");
  }
});

var server = app.listen(8081, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Example app listening at http://%s:%s", host, port)

})